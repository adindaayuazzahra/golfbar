<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('cssPage'); ?>
</head>

<body>
    <?php echo $__env->yieldContent('navbar'); ?>
    <div id="canvas" class="d-flex align-items-center justify-content-center">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('jsPage'); ?>
</body>

</html><?php /**PATH C:\laragon\www\golfbar\resources\views/layout/web.blade.php ENDPATH**/ ?>