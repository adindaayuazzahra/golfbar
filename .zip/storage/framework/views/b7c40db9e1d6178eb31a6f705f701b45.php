

<?php $__env->startSection('cssPage'); ?>
<style>
    #canvas {
        height: 100vh;
    }
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container p-0 d-flex  align-items-center justify-content-center">
    <div class="card my-4 mx-4 my-md-5 shadow shadow-md-lg" style="border-radius: 20px;border:none;">
        <img class="card-img-top img-cover" src="<?php echo e(asset('img/header3.png')); ?>"
            style="max-height: 350px;border-radius: 20px 20px 0 0">
        <div class="card-body d-flex flex-column justify-content-center align-items-center">
            <h5>Terima Kasih Anda Sudah Berhasil Mengisi Form Konfirmasi Kehadiran!</h5>
            <p>Untuk info lebih lanjut akan di hubungi melalui Whatsapp.</p>
            <p class="mt-3"><span class="fw-bold">Contact Person</span> : 085215609439 <span class="fw-bold">(ARI
                    SETYAWAN)</span></p>

        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\golfbar\resources\views/admin/konfirmasi.blade.php ENDPATH**/ ?>