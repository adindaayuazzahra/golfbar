<?php $__env->startSection('cssPage'); ?>
<style>
    #canvas {
        height: 100vh;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card shadow-lg" style="border-radius:20px;">
    <div class="card-body">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center my-3">
                <h3><strong>List Peserta</strong></h3>
                <div class="d-flex ">
                    <a href="<?php echo e(route('admin.home')); ?>" class="btn btn-secondary me-2" style="border-radius: 5px;">
                        <i class="fa-solid fa-arrow-left-long"></i>
                    </a>
                    <form action="<?php echo e(route('users.import')); ?>" class="d-flex" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="file" name="file" class="form-control me-2">

                        <button class="btn btn-success">IMPORT</button>
                    </form>
                    
                </div>
            </div>
            

            <table id="list" class="table text-white" width="100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama</th>
                        <th>Instansi</th>
                        <th>Size</th>
                        <th>Whatsapp</th>
                        <th>Grup</th>
                        <th>Status</th>
                        <th>Hadiah</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pesertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($p->id); ?></td>
                        <td><?php echo e($p->nama); ?></td>
                        <td><?php echo e($p->instansi); ?></td>
                        <td><?php echo e($p->ukuran_baju); ?></td>
                        <td><?php echo e($p->whatsapp); ?></td>
                        <td>
                            <?php if($p->id_grup == 0): ?>
                            -
                            <?php else: ?>
                            <?php echo e($p->grup->nama_grup); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($p->status == 0): ?>
                            <div class="badge rounded-pill text-bg-danger">Tidak Hadir</div>
                            <?php elseif($p->status == 1): ?>
                            <div class="badge rounded-pill text-bg-primary">Hadir</div>
                            <?php elseif($p->status == 2): ?>
                            <div class="badge rounded-pill text-bg-success">Registrasi</div>
                            <?php elseif($p->status == 3): ?>
                            <div class="badge rounded-pill text-bg-warning">Menang Doorprize</div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($p->id_hadiah): ?>
                            <?php echo e($p->hadiah->nama_hadiah); ?>

                            <?php else: ?>
                            -
                            <?php endif; ?>
                        </td>
                        <td>
                            
                            <a href="<?php echo e(route('admin.download.qr', ['id' => $p->id])); ?>"
                                class="btn btn-warning rounded-circle"><i class="fa-solid fa-qrcode"></i></a>
                            
                            
                            <a href="https://wa.me/62<?php echo e($p->whatsapp); ?>" target="_blank"
                                class="btn btn-success rounded-circle"><i class="fa-brands fa-whatsapp"></i></a>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsPage'); ?>
<script>
    $(document).ready(function() {
        $('#list').DataTable({
            responsive: true, // Opsi jumlah entri per halaman yang dapat dipilih
            pageLength: 10, // Jumlah entri per halaman
            lengthMenu: [5, 8, 10]
        , });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\golfbar\resources\views/admin/list-peserta.blade.php ENDPATH**/ ?>