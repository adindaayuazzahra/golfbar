
<?php $__env->startSection('cssPage'); ?>
<style>
    #canvas {
        height: 100vh;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- index.blade.php -->
<div class="container-fluid text-center">
    <div class="row justify-content-start">
        <p class="label-1 fw-bold my-3" style="font-size: 16pt;">System Powered By General Affair Section PT Jasamarga
            Tollroad Maintenance
        </p>
    </div>
    <div class="row justify-content-start">
        <?php $__currentLoopData = $grups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 mb-3">
            <div class="card shadow-lg h-100" style="border-radius:20px;background-color:#277BC0">
                <div class="card-body p-2">
                    <h3 class="card-title text-white header-1 mb-2"><?php echo e($grup->nama_grup); ?></h3>
                    <ul class="list-group list-group-flush h-100" style="border-radius:20px;">
                        <?php $__currentLoopData = $grup->peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item label-1 py-1" style="font-size:14pt;"><?php echo e($peserta->nama); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<script>
    setTimeout(() => {
        location.reload()
    }, 2000);
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\golfbar\resources\views/admin/grup-view.blade.php ENDPATH**/ ?>