<?php $__env->startSection('cssPage'); ?>
<style>
    #canvas {
        height: 100vh;
    }

    #preview video {
        transform: scaleX(-1);
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container d-flex flex-column align-items-center justify-content-center">
    <div class="card bg-transparent">
        <div id="preview" style="width:50vw"></div>
        <form id="form" action="<?php echo e(route('admin.scan.do')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="nama" id="nama">
        </form>
        <!-- Button trigger modal -->
    </div>

    

</div>


<div class="modal fade" id="confirmationModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content p-4">
            <div class="d-flex text-center flex-column justify-content-center mb-3">
                <p class="mb-0">Registrasi atas nama</p>
                <h4 id="confirmationNPP"></h4>
            </div>
            <div class="d-grid gap-2 d-flex justify-content-center">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="button" class="btn btn-primary" onclick="submitForm()">Registrasi</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Input Manual -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsPage'); ?>
<script src="<?php echo e(asset('js/html5-qrcode.min.js')); ?>"></script>
<script type="text/javascript">
    let html5QrcodeScanner = new Html5QrcodeScanner(
        "preview", { fps: 10,  qrbox: { width: 350, height: 350 }},
       false
    );

    html5QrcodeScanner.render(onScanSuccess);

    function onScanSuccess(decodedText) {
        console.log(decodedText);
        // Tampilkan modal konfirmasi
        document.getElementById('confirmationNPP').textContent = decodedText;
        $('#confirmationModal').modal('show');
    }

    function submitForm() {
        // Submit formulir setelah konfirmasi
        document.getElementById('nama').value = document.getElementById('confirmationNPP').textContent;
        document.getElementById('form').submit();
    }
</script>

<?php if(session('message')): ?>
<script>
    Swal.fire({
        timer: 5000,
        icon: '<?php echo e(session('icon')); ?>',
        title: '<?php echo e(session('title')); ?>',
        text: '<?php echo e(session('message')); ?>',
    });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\golfbar\resources\views/admin/scan.blade.php ENDPATH**/ ?>