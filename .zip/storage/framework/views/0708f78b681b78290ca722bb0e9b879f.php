<?php $__env->startSection('cssPage'); ?>
<style>
    #canvas {
        height: 100vh;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container col">
    <div class="row justify-content-center mb-3 d-grid gap-2">
        <a href="<?php echo e(route('logout.do')); ?>" class="btn btn-danger btn-lg" style="border-radius:30px;">
            <h4>Logout <i class="fa-solid fa-right-from-bracket"></i></h4>
        </a>
    </div>
    <div class="row justify-content-center ">
        <a href="<?php echo e(route('admin.scan')); ?>" class="card mt-2 me-2 text-center btn text-white"
            style="width:350px;border-radius:10px;background-color: #277BC0">
            <div class="card-body">
                <h5>Scan QrCode</h5>
                <i class="fa-solid fa-qrcode mt-3" style="font-size: 30pt;"></i>
            </div>
        </a>
        <a href="<?php echo e(route('admin.list.peserta')); ?>" class="card mt-2 me-2 text-center btn text-white"
            style="width:350px;border-radius:10px;background-color: #277BC0">
            <div class="card-body">
                <h5>List Peserta</h5>
                <i class="fa-solid fa-user-group mt-3" style="font-size: 30pt;"></i>
            </div>
        </a>
        <a href="<?php echo e(route('admin.list.hadiah')); ?>" class="card mt-2 me-2 text-center btn text-white"
            style="width:350px;border-radius:10px;background-color: #277BC0">
            <div class="card-body">
                <h5>List Hadiah </h5><i class="fa-solid fa-gift mt-3" style="font-size: 30pt;"></i>
            </div>
        </a>
        <a href="<?php echo e(route('admin.list.grup')); ?>" class="card mt-2 me-2 text-center btn text-white"
            style="width:350px;border-radius:10px;background-color: #277BC0">
            <div class="card-body">
                <h5>List Grup</h5><i class="fa-solid fa-people-group mt-3" style="font-size: 30pt;"></i>
            </div>
        </a>
        <a href="<?php echo e(route('admin.flight.view')); ?>" class="card mt-2 me-2 text-center btn text-white"
            style="width:350px;border-radius:10px;background-color: #277BC0">
            <div class="card-body">
                <h5>Flight</h5><i class="fa-solid fa-golf-ball-tee mt-3" style="font-size: 30pt;"></i>
            </div>
        </a>
        
        
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\golfbar\resources\views/admin/home.blade.php ENDPATH**/ ?>