<?php $__env->startSection('content'); ?>
<div class="container p-0 d-flex  align-items-center justify-content-center">
    <div class="card my-4 mx-4 my-md-5 shadow shadow-md-lg" style="border-radius: 20px;border:none;">
        <img class="card-img-top img-cover" src="<?php echo e(asset('img/header3.png')); ?>"
            style="max-height: 350px;border-radius: 20px 20px 0 0 ">
        <div class="col mt-3 px-2">
            <h1 class="text-center header-1 display-3"
                style="border-bottom:10px solid #F1C376; border-top:10px solid #F1C376;">
                RSVP
            </h1>
            <h1 class="text-center header-1 hijau display-4">JASA MARGA FUN GOLF</h1>
            <p class="mt-1 text-center">Powered By<span class="fw-bold"> PT JASAMARGA TOLLROAD MAINTENANCE</span>

        </div>
        <div class="card-body ">

            <form action="<?php echo e(route('register.do')); ?>" class="m-2 m-md-4" method="POST">
                <?php echo e(csrf_field()); ?>

                
                <div class="mb-4 position-relative">
                    <p class="mb-3"><span class="fw-bold"><span class="text-danger">*</span>Contact Person</span> :
                        085215609439 <span class="fw-bold">(ARI
                            SETYA)</span></p>
                    <label style="font-size:14pt;" for="nama" class="form-label label-1 mb-1">Nama Lengkap <span
                            class="text-danger">*</span></label>
                    <input autocomplete="off" type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="nama" id="nama" value="<?php echo e(old('nama')); ?>">
                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-4 position-relative">
                    <label style="font-size:14pt;" for="instansi" class="form-label label-1 mb-1">Unit Kerja<span
                            class="text-danger">*</span></label>
                    <input autocomplete="off" type="text" class="form-control <?php $__errorArgs = ['instansi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="instansi" id="instansi" value="<?php echo e(old('instansi')); ?>">
                    <?php $__errorArgs = ['instansi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-4 position-relative">
                    <label style="font-size:14pt;" for="whatsapp" class="form-label label-1 mb-1">No. Whatsapp <span
                            class="text-danger">*</span></label>
                    <p class="fw-light fst-italic lh-sm">(*) Format Nomor : 08XXXXXXX</p>
                    <input autocomplete="off" type="number" class="form-control <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="whatsapp" id="whatsapp" value="<?php echo e(old('whatsapp')); ?>">
                    <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4 position-relative">
                    <label style="font-size:14pt;" for="ukuran_baju" class="form-label label-1 mb-2">Ukuran Baju<span
                            class="text-danger">*</span></label>
                    <select class="form-select <?php $__errorArgs = ['ukuran_baju'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ukuran_baju"
                        name="ukuran_baju">
                        <option selected>Pilih Ukuran Baju</option>
                        <option value="S">S</option>
                        <option value="M">M</option>
                        <option value="L">L</option>
                        <option value="XL">XL</option>
                        <option value="XXL">XXL</option>
                    </select>
                    <?php $__errorArgs = ['ukuran_baju'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4 position-relative">
                    <label style="font-size:14pt;" for="status" class="form-label label-1 mb-2">Apakah anda
                        bersedia
                        untuk hadir ? <span class="text-danger">*</span></label><br>

                    <input type="radio" class="btn-check <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="status" value="y"
                        id="hadir" autocomplete="off" checked>
                    <label class="btn btn-outline-success rounded-pill me-1 mb-1" style="font-weight: bold"
                        for="hadir">Hadir</label>

                    <input type="radio" class="btn-check rounded <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="status"
                        value="n" id="tidak" autocomplete="off">
                    <label class="btn btn-outline-danger rounded-pill mb-1" style="font-weight: bold" for="tidak">Tidak
                        Hadir</label>

                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary mt-3 rounded-pill">KIRIM</button>
                    
                </div>


            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsPage'); ?>
<?php if(session('message')): ?>
<script>
    Swal.fire({
        timer: 2000,
        icon: '<?php echo e(session('icon')); ?>',
        title: '<?php echo e(session('title')); ?>',
        text: '<?php echo e(session('message')); ?>',
    });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\golfbar\resources\views/registrasi.blade.php ENDPATH**/ ?>